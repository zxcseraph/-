#include "closecellall.h"


static const char const_tag_id[] = "$Name: Rel_5_00_20111208_closecell $"; 
char tag_id[] = "$Name: Rel_5_00_20111208_closecell $";

using namespace	TLogFunction; 

//��ʼ������
bool init()
{
	if(!TCLOSECELL::getInstance()->startup())
	{
		logError("init TClosecell failed");
		return false;
	}
	if(!TClosecellConfig::getInstance()->startup())
	{
		logError("init TClosecellConfig failed");
		return false;
	}
	return true;
}

int main(int argc, char **argv){
	char ch;
	char *file[6];
	int fNum = 0;

	if(!init()){
		fprintf(stderr, "inialize failed\n");
		return -1;
	}       

	opterr = 0;
	//��ȡ����
	if((ch = getopt(argc,argv,"hf:"))!= -1){ 
		switch(ch) {
		case 'h':
			fprintf(stderr,"please input \"-f file\"\n");
			return -1;
			break;
		case 'f':
			break;
		default:
			fprintf(stderr,"ERROR: input the data 4from file\n");
			logError("input the data from file");
			return -1;
		}
	}
	else{
		fprintf(stderr, "getopt error\n");
		return -1;
	}

	//�����ļ���
	file[fNum++] = optarg;
	for(optind; optind < argc; optind++)
		file[fNum++] = argv[optind];

	TCLOSECELL::getInstance()->define_file(file, fNum);

	return -1;
}

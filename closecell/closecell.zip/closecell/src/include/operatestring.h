#ifndef _OPERATE_STRING_H
#define _OPERATE_STRING_H

#include "closecellconfig.h"

bool hand_string_lbs_td(char *, char *, char *, double *, double *, TClosecellLocationRuleItem closeCellLoc);
bool hand_string_lbs_2d(char *, char *, char *, double *, double *, TClosecellLocationRuleItem closeCellLoc);
bool hand_string_closecell(char *, char *, char *, char *, char *, TClosecellRuleItem closeCellLoc);
void hand_string_2DTD(char *, char *, char *, char *);
void merge_string(char *, char *, char *, char *);

#endif

